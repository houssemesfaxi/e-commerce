<?php
require 'db.php';

// Ajout d'une commande
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $client_id = $_POST['client_id'];
    $date_commande = $_POST['date_commande'];
    $etat_commande = $_POST['etat_commande'];

    $sql = "INSERT INTO commandes (client_id, date_commande, etat_commande) VALUES ('$client_id', '$date_commande', '$etat_commande')";
    if ($conn->query($sql) === TRUE) {
        echo "Nouvelle commande ajoutée avec succès";
    } else {
        echo "Erreur: " . $sql . "<br>" . $conn->error;
    }
}

// Lecture des commandes
$sql = "SELECT * FROM commandes";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<li>ID: " . $row["id"] . " - Client ID: " . $row["client_id"] . " - Date: " . $row["date_commande"] . " - Etat: " . $row["etat_commande"] . "</li>";
    }
} else {
    echo "0 commandes";
}

$conn->close();
?>
