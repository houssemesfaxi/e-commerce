<?php
require 'db.php';

// Ajout d'un article
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nom = $_POST['nom'];
    $description = $_POST['description'];
    $prix_achat = $_POST['prix_achat'];
    $prix_vente = $_POST['prix_vente'];
    $taux_tva = $_POST['taux_tva'];
    $quantite_stock = $_POST['quantite_stock'];

    $sql = "INSERT INTO articles (nom, description, prix_achat, prix_vente, taux_tva, quantite_stock) VALUES ('$nom', '$description', '$prix_achat', '$prix_vente', '$taux_tva', '$quantite_stock')";
    if ($conn->query($sql) === TRUE) {
        echo "Nouvel article ajouté avec succès";
    } else {
        echo "Erreur: " . $sql . "<br>" . $conn->error;
    }
}

// Lecture des articles
$sql = "SELECT * FROM articles";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<li>ID: " . $row["id"] . " - Nom: " . $row["nom"] . " - Prix de vente: " . $row["prix_vente"] . "</li>";
    }
} else {
    echo "0 articles";
}

$conn->close();
?>
