document.addEventListener('DOMContentLoaded', function() {
    const articleForm = document.getElementById('article-form');
    const articleList = document.getElementById('article-list');

    articleForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(articleForm);
        fetch('articles.php', {
            method: 'POST',
            body: formData
        }).then(response => response.text())
          .then(data => {
              articleList.innerHTML = data;
              articleForm.reset();
          });
    });

    function loadArticles() {
        fetch('articles.php')
            .then(response => response.text())
            .then(data => {
                articleList.innerHTML = data;
            });
    }

    loadArticles();
});
