document.addEventListener('DOMContentLoaded', function() {
    const fournisseurForm = document.getElementById('fournisseur-form');
    const fournisseurList = document.getElementById('fournisseur-list');

    fournisseurForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(fournisseurForm);
        fetch('fournisseurs.php', {
            method: 'POST',
            body: formData
        }).then(response => response.text())
          .then(data => {
              fournisseurList.innerHTML = data;
              fournisseurForm.reset();
          });
    });

    function loadFournisseurs() {
        fetch('fournisseurs.php')
            .then(response => response.text())
            .then(data => {
                fournisseurList.innerHTML = data;
            });
    }

    loadFournisseurs();
});
