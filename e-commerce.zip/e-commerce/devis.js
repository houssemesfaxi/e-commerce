document.addEventListener('DOMContentLoaded', function() {
    const devisForm = document.getElementById('devis-form');
    const devisList = document.getElementById('devis-list');

    devisForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(devisForm);
        fetch('devis.php', {
            method: 'POST',
            body: formData
        }).then(response => response.text())
          .then(data => {
              devisList.innerHTML = data;
              devisForm.reset();
          });
    });

    function loadDevis() {
        fetch('devis.php')
            .then(response => response.text())
            .then(data => {
                devisList.innerHTML = data;
            });
    }

    loadDevis();
});
