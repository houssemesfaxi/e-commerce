<?php
require 'db.php';

// Ajout d'un devis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $client_id = $_POST['client_id'];
    $date_devis = $_POST['date_devis'];
    $etat_devis = $_POST['etat_devis'];

    $sql = "INSERT INTO devis (client_id, date_devis, etat_devis) VALUES ('$client_id', '$date_devis', '$etat_devis')";
    if ($conn->query($sql) === TRUE) {
        echo "Nouveau devis ajouté avec succès";
    } else {
        echo "Erreur: " . $sql . "<br>" . $conn->error;
    }
}

// Lecture des devis
$sql = "SELECT * FROM devis";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<li>ID: " . $row["id"] . " - Client ID: " . $row["client_id"] . " - Date: " . $row["date_devis"] . " - Etat: " . $row["etat_devis"] . "</li>";
    }
} else {
    echo "0 devis";
}

$conn->close();
?>
