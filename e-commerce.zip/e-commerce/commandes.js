document.addEventListener('DOMContentLoaded', function() {
    const commandeForm = document.getElementById('commande-form');
    const commandeList = document.getElementById('commande-list');

    commandeForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(commandeForm);
        fetch('commandes.php', {
            method: 'POST',
            body: formData
        }).then(response => response.text())
          .then(data => {
              commandeList.innerHTML = data;
              commandeForm.reset();
          });
    });

    function loadCommandes() {
        fetch('commandes.php')
            .then(response => response.text())
            .then(data => {
                commandeList.innerHTML = data;
            });
    }

    loadCommandes();
});
