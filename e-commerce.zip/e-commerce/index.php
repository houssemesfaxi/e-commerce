<?php
session_start();
require 'db.php';

function renderForm($entity, $fields) {
    echo "<h2>Ajouter un $entity</h2>";
    echo "<form method='post' action='{$entity}.php'>";
    foreach ($fields as $field) {
        echo ucfirst($field) . ": <input type='text' name='$field'><br>";
    }
    echo "<input type='submit' value='Ajouter'>";
    echo "</form>";
    echo "<h2>Liste des $entity</h2>";
    include "{$entity}.php";
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>monoshop</title>
</head>

<body>
    <h1>Monoshop</h1>

    <div>
        <h2>Connexion</h2>
        <form method="post" action="auth.php">
            Login: <input type="text" name="login"><br>
            Mot de passe: <input type="password" name="password"><br>
            <input type="submit" value="Se connecter">
        </form>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
        <div>
            <h2>Bienvenue</h2>
            <a href="logout.php">Déconnexion</a>
        </div>

        <div>
            <h2>Gestion des entités</h2>
            <ul>
                <li><a href="?entity=clients">Clients</a></li>
                <li><a href="?entity=articles">Articles</a></li>
                <li><a href="?entity=commandes">Commandes</a></li>
                <li><a href="?entity=devis">Devis</a></li>
                <li><a href="?entity=fournisseurs">Fournisseurs</a></li>
            </ul>
        </div>
                   
        <?php
        if (isset($_GET['entity'])) {
            $entity = $_GET['entity'];
            switch ($entity) {
                case 'clients':
                    renderForm('clients', ['login', 'password', 'nom', 'prenom', 'adresse', 'telephone', 'email']);
                    break;
                case 'articles':
                    renderForm('articles', ['nom', 'description', 'prix_achat', 'prix_vente', 'taux_tva', 'quantite_stock']);
                    break;
                case 'commandes':
                    renderForm('commandes', ['client_id', 'date_commande', 'etat_commande']);
                    break;
                case 'devis':
                    renderForm('devis', ['client_id', 'date_devis', 'etat_devis']);
                    break;
                case 'fournisseurs':
                    renderForm('fournisseurs', ['nom', 'adresse', 'telephone', 'email']);
                    break;
            }
        }
        ?>
    <?php endif; ?>
</body>
</html>
