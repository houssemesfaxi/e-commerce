<?php
session_start();
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = $_POST['login'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM clients WHERE login = ?");
    $stmt->execute([$login]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['mot_de_passe'])) {
        $_SESSION['user_id'] = $user['client_id'];
        header("Location: dashboard.php");
    } else {
        echo "Invalid login or password";
    }
}
?>

<form method="post">
    <input type="text" name="login" placeholder="Login" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
</form>
