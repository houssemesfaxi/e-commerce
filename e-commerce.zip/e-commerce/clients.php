<?php
require 'db.php';

// Ajouter un client
if (isset($_POST['add_client'])) {
    $login = $_POST['login'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $adresse = $_POST['adresse'];
    $telephone = $_POST['telephone'];
    $email = $_POST['email'];

    $stmt = $pdo->prepare("INSERT INTO clients (login, mot_de_passe, nom, prenom, adresse, telephone, email) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$login, $password, $nom, $prenom, $adresse, $telephone, $email]);
}

// Supprimer un client
if (isset($_GET['delete_client'])) {
    $client_id = $_GET['delete_client'];
    $stmt = $pdo->prepare("DELETE FROM clients WHERE client_id = ?");
    $stmt->execute([$client_id]);
}

// Afficher les clients
$stmt = $pdo->query("SELECT * FROM clients");
$clients = $stmt->fetchAll();
?>

<h1>Gestion des clients</h1>
<form method="post">
    <input type="text" name="login" placeholder="Login" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="text" name="nom" placeholder="Nom" required>
    <input type="text" name="prenom" placeholder="Prénom" required>
    <input type="text" name="adresse" placeholder="Adresse">
    <input type="text" name="telephone" placeholder="Téléphone">
    <input type="email" name="email" placeholder="Email">
    <button type="submit" name="add_client">Ajouter</button>
</form>

<h2>Liste des clients</h2>
<ul>
    <?php foreach ($clients as $client): ?>
        <li>
            <?php echo $client['nom'] . ' ' . $client['prenom']; ?>
            <a href="?delete_client=<?php echo $client['client_id']; ?>">Supprimer</a>
        </li>
    <?php endforeach; ?>
</ul>
