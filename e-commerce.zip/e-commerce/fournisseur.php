<?php
require 'db.php';

// Ajout d'un fournisseur
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nom = $_POST['nom'];
    $adresse = $_POST['adresse'];
    $telephone = $_POST['telephone'];
    $email = $_POST['email'];

    $sql = "INSERT INTO fournisseurs (nom, adresse, telephone, email) VALUES ('$nom', '$adresse', '$telephone', '$email')";
    if ($conn->query($sql) === TRUE) {
        echo "Nouveau fournisseur ajouté avec succès";
    } else {
        echo "Erreur: " . $sql . "<br>" . $conn->error;
    }
}

// Lecture des fournisseurs
$sql = "SELECT * FROM fournisseurs";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<li>ID: " . $row["id"] . " - Nom: " . $row["nom"] . " - Email: " . $row["email"] . "</li>";
    }
} else {
    echo "0 fournisseurs";
}

$conn->close();
?>
