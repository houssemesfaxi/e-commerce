document.addEventListener('DOMContentLoaded', function() {
    const clientForm = document.getElementById('client-form');
    const clientList = document.getElementById('client-list');

    clientForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(clientForm);
        fetch('clients.php', {
            method: 'POST',
            body: formData
        }).then(response => response.text())
          .then(data => {
              clientList.innerHTML = data;
              clientForm.reset();
          });
    });

    function loadClients() {
        fetch('clients.php')
            .then(response => response.text())
            .then(data => {
                clientList.innerHTML = data;
            });
    }

    loadClients();
});
